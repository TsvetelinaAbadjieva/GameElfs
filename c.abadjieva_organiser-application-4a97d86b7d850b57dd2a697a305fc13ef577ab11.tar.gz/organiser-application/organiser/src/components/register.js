import React from "react";

export class Register extends React.Component {


    constructor(props) {
        super(props)

        this.state = {
            username: '',
            email: '',
            passsword: '',
            message: ''
        }

    }
    updateInputUsername(evt) {
        this.setState({
            username: evt.target.value,
        });
    }
    updateInputEmail(evt) {
        this.setState({
            email: evt.target.value,
        });

    }
    updateInputPassword(evt) {
        this.setState({
            password: evt.target.value
        });
        console.log(evt.target.value)
    }


    render() {

        function validateUsername(that) {
            if (that.state.username == '') {
                updateMessage('Field username is required!', that);
                return false;
            }
            if (that.state.username.length < 5) {
                updateMessage('Field username must be at least 5 symbols!', that);
                return false;
            }
            return true;
        }

        function validateEmail(that) {
            var patt = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            
            var res = patt.test(that.state.email);
            if(!res) {
               updateMessage('Please, enter a valid email',that);
               return false;
            } else {
                updateMessage('',that);
                return true;
            }
        }

        function validatePassword(that) {

            var patt = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*(_|[^\w])).+$/;
            var res = patt.test(that.state.password);

            if(!res) {
               updateMessage('Password must be at least 6 symbols included one or more upercase and numbers',that);
               return false;
            } else {
                updateMessage('',that);
                return true;
            }
            if(that.state.passsword.length < 6) {
                updateMessage('Password must be at least 6 symbols', that);
                return false;
            }
        }
        function generateToken() {

        }
        function hash(pass) {

        }
         function hashCode(pass){
            var hash = 0;
            if (pass.length == 0) return hash;
            for (var i = 0; i < pass.length; i++) {
              var  char = pass.charCodeAt(i);
                hash = ((hash<<5)-hash)+char;
                hash = hash & hash; // Convert to 32bit integer
            }
            return hash;
        }

        function onRegister() {

            if(validateUsername(this) &&  validateEmail(this) && validatePassword(this)){

                var user = {
                    username: this.state.username,
                    email: this.state.email,
                    passsword: hashCode(this.state.passsword),
                    token: generateToken()
                }
                var userString = JSON.stringify(user);
                var xhttp = new XMLHttpRequest();
                xhttp.open('POST','http://localhost:8000/insertuser', true);
                xhttp.setRequestHeader("Content-type", "application/json");
                xhttp.onreadystatechange = function() {//Call a function when the state changes.
                    if(xhttp.readyState == 4 && xhttp.status == 200) {
                        alert(xhttp.responseText);
                    }
                }
                xhttp.send(userString);
            } 
                return true;
        }

        function updateMessage(message, that) {

            that.setState({
                message: message
            });
          //return this.state.message;
        }

        return (
            <div className="col-md-6 form-group">Login Form
                <div>
                    <p><label for="exampleInputEmail1">Username</label></p>
                    <p><input type="text" className="form-group" id="username" name="username" value={this.state.username} onChange={evt => this.updateInputUsername(evt)} aria-describedby="emailHelp" placeholder="Enter username" /></p>

                    <p><label for="exampleInputEmail1">Email address</label></p>
                    <p><input type="email" className="form-group" id="email" name="email" value={this.state.email} onChange={evt => this.updateInputEmail(evt)} aria-describedby="emailHelp" placeholder="Enter email" /></p>
                    <p><label for="exampleInputEmail1">Password</label></p>
                    <p><input type="text" className="form-group" id="password" name="password" value={this.state.password} onChange={evt => this.updateInputPassword(evt)} /></p>
                </div>

                <p><button onClick={onRegister.bind(this)} id="login" name="register" type="submit">Register</button></p>
                <p>{this.state.username} -- {this.state.email}--{this.state.password}--{this.state.message}</p>
                <p>{this.state.message}</p>

            </div>
        );


    }
}