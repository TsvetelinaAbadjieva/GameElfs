import React from "react";

export class Login extends React.Component {
    
 constructor(props){
        super(props)
       
        this.state ={
            username : '',
            passsword : ''
        }
    
    }
    updateInputUsername(evt) {
        this.setState({
            username: evt.target.value,
        });
        console.log(evt.target.value)
    }   
    updateInputPassword(evt) {
        this.setState({
            password: evt.target.value
        });
        console.log(evt.target.value)
    }   
    
    onLogin(){
        //this.setState(this.state);
    
    }
    render() {
        
         return(
            <div className="col-md-6 form-group">Login Form
                <div>
                    <p><label for="exampleInputEmail1">Email address</label></p>
                    <p><input type="email" className="form-group" id="username" name="username" value={this.state.username} onChange={evt => this.updateInputUsername(evt)} aria-describedby="emailHelp" placeholder="Enter email"/></p>
                    <p><label for="exampleInputEmail1">Password</label></p>
                    <p><input type="text" className="form-group" id="password" name="password" value={this.state.password} onChange={evt => this.updateInputPassword(evt)}/></p>
                </div>
            
                <p><button onClick={()=>this.onLogin} id="login" name="login" type="submit">Login</button></p>
                <p>{this.state.username} -- {this.state.password}</p>
            </div>
        );

         
    }
}