import React from "react";
import {Link} from "react-router";


export const Home =(props)=> {
    
   // render() {
        
         return(

            <div className="row"> 
                <div className="container">
                    <div className="container">
                        <nav className="navbar navbar-inverse navbar-static-top">
                            <ul className="menu">
                                <li><Link to={'/'}activeStyle={{color:"lightblue"}}>Home</Link></li>
                                <li><Link to={"/login/"} activeStyle={{color:"lightblue"}}>Login</Link></li>
                                <li><Link to={"/register"} activeStyle={{color:"lightblue"}}>Register</Link></li>
                                <li><Link to={"/task/"} activeStyle={{color:"lightblue"}}>Task</Link></li> 
                            </ul>
                        </nav>
                    </div>
                    <div className="img">
                        <img src="http://www.smallpaperthings.com/wp-content/uploads/2015/10/FullSizeRender-5-1024x768.jpg" alt=""/>
                    </div>
                </div>
            </div>
        );

         
   //}
};