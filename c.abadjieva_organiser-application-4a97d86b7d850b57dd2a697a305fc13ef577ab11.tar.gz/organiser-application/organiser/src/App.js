import React, { Component } from 'react';
import {render} from 'react-dom';
import logo from './logo.svg';
import './App.css';
import {Router, Route, browserHistory, IndexRoute} from 'react-router';

import {Login} from './components/login';
import {Register} from './components/register';
import {Home} from './components/home';
import {Task} from './components/task';

class App extends Component {

  render() {

    return (
     
     <Router history={browserHistory}>
        <Route path={"/"} component={Home}/>
          <Route path={"Home"} component={Home}/>
          <Route path={"Login/:id"} component={Login}/>
          <Route path={"Register"} component={Register}/>
          <Route path={"Task/:id"} component={Task}/>
    <p>Hello</p>    
    </Router>   
  
    );
  }
}
/*          <IndexRoute component={Home}/>
*/
export default App;
