var mysql = require('mysql');
var con = mysql.createConnection({
  host:     "localhost",
  user:     "root",
  password: "root",
  database: "organiser"
});

con.connect(function(err) {

  if (err) throw err;
  console.log("Connected!");

  var sqlUser = "CREATE TABLE organiser.user (id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, username VARCHAR(255), email VARCHAR(255), password VARCHAR(255), token VARCHAR(255))";
  var sqlGroup = "CREATE TABLE organiser.group (id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, `group` VARCHAR(255))";
  var sqlPriority = "CREATE TABLE organiser.priority (id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY, priority VARCHAR(255))";
  var sqlTask = "CREATE TABLE organiser.task ( id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL , priority_id INT NOT NULL , group_id INT NOT NULL ,  period_id INT NOT NULL ,title VARCHAR(255) NOT NULL, description VARCHAR(500) NOT NULL , start_date DATE  NOT NULL, start_time TIME NOT NULL , due_date DATE NOT NULL , due_time TIME NOT NULL;";
  var sqlPeriod = "CREATE TABLE `organiser`.`period` ( `id` INT NOT NULL AUTO_INCREMENT , `period` VARCHAR(255) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci;"

  //CREATE TABLE `organiser`.`user` ( `id` INT NOT NULL AUTO_INCREMENT , `username` VARCHAR(255) NOT NULL ,`email`VARCHAR(255) NOT NULL, `password` VARCHAR(255) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci;
  //CREATE TABLE `organiser`.`priority` ( `id` INT NOT NULL AUTO_INCREMENT , `priority` VARCHAR(255) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci;
 //CREATE TABLE `organiser`.`group` ( `id` INT NOT NULL AUTO_INCREMENT , `group` VARCHAR(255) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci;
  //CREATE TABLE `organiser`.`task` ( `id` INT NOT NULL AUTO_INCREMENT , `user_id` INT NOT NULL , `priority_id` INT NOT NULL , `group_id` INT NOT NULL , `title` VARCHAR(255) NOT NULL , `description` VARCHAR(500) NOT NULL , `start_date` DATE NOT NULL , `start_time` TIME NOT NULL , `due_date` DATE NOT NULL , `due_time` TIME NOT NULL , `period_id` INT NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARACTER SET utf8 COLLATE utf8_general_ci;
 
  con.query(sqlUser, function (err, result) {
    if (err) throw err;
    console.log("Table User created");
  });

  con.query(sqlGroup, function (err, result) {
    if (err) throw err;
    console.log("Table Group created");
  });

    con.query(sqlPriority, function (err, result) {
    if (err) throw err;
    console.log("Table Priority created");
  });

con.query(sqlPeriod, function (err, result) {
    if (err) throw err;
    console.log("Table PERIOD created");
  });
/*
  con.query('DROP table task', function (err, result) {
    if (err) throw err;
    console.log("Table PERIOD dropped");
  });
 */
  con.query(sqlTask, function (err, result) {
    if (err) throw err;
    console.log("Table Task created");
  });
  
});





