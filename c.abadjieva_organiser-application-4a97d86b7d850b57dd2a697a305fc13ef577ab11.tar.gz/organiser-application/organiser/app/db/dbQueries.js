var mysql = require('mysql');
var con = mysql.createConnection({

    host:       "localhost",
    user:       "root",
    password:   "root",
    database:   "organiser"
});

con.connect(function (err) {
    if (err) throw err;
});

exports.insertUser = function (username, email, password) {

    var users = [];
    //INSERT INTO `user` (`name`) VALUES ('John'); 
    var sql = "INSERT INTO `user` (`username`, `password`, `email`) VALUES ?";
    users.push(username);
    users.push(password);
    users.push(email);

    var values = [users];

    con.query(sql, [values], function (err, result) {
        if (err) throw err;
        console.log("Number of records inserted: " + result.affectedRows);
    });
};

exports.getUserCollection = function(func) {

var sql = "SELECT * FROM user";
var user = [];

    con.query(sql, function (err, result) {
      if (err) throw err;
      for (var i = 0; i < result.length; i++) {
         user.push(result[i]);
    }
        console.log(result);
      func(JSON.stringify(user));
    });
};

exports.updateToken = function (username, email, token) {

    //INSERT INTO `user` (`name`) VALUES ('John'); 
    var sql = "UPDATE user SET token = ? WHERE (username = ? AND email = ?);" ;
    con.query(sql, [username,email,token], function (err, result) {
        if (err) throw err;
        console.log("Number of records updated: " + result.affectedRows);
    });
};

exports.checkUser = function (username, password) {

    var users = [];
    var sql = "SELECT `username`, `password` FROM user WHERE username = ? AND password = ?";
    users.push(username);
    users.push(password);

    var values = [users];

    con.query(sql, [values], function (err, result) {
        if (err) throw err;
        if (result.numRows > 0) return true;
        return false;
    });
};
exports.insertGroup = function (group) {

    var sql = "INSERT INTO `group` SET `group` = ?";
    var values = [[group]];

    con.query(sql,[values], function (err, result) {
        if (err) throw err;
        console.log("Number of records inserted into Group: " + result.affectedRows);
    });
};

exports.insertPriority = function (priority) {

    var sql = "INSERT INTO `priority` SET `priority` = ?";
    var values = [[priority]];

    con.query(sql,[values], function (err, result) {
        if (err) throw err;
        console.log("Number of records inserted into Priority: " + result.affectedRows);
    });
};
exports.deletePriority = function (id) {

    var sql = "DELETE FROM `priority` WHERE id = ?";
    var values = [[id]];

    con.query(sql,[values], function (err, result) {
        if (err) throw err;
        console.log("Number of records inserted into Priority: " + result.affectedRows);
    });
};

exports.insertPeriod = function (period) {

    var sql = "INSERT INTO `period` SET `period` = ?";
    var values = [[period]];

    con.query(sql,[values], function (err, result) {
        if (err) throw err;
        console.log("Number of records inserted into Period: " + result.affectedRows);
    });
};

exports.deletePeriod = function (id) {

    var sql = "DELETE FROM `period` WHERE id = ?";
    var values = [[id]];

    con.query(sql,[values], function (err, result) {
        if (err) throw err;
        console.log("Number of records inserted into Priority: " + result.affectedRows);
    });
};


//here task is an object
exports.insertTask = function (task) {

    var taskArray = [];
    taskArray.push(task.user_id);
    taskArray.push(task.priority_id);
    taskArray.push(task.group_id);
    taskArray.push(task.title);
    taskArray.push(task.description);
    taskArray.push(task.start_date);
    taskArray.push(task.start_time);
    taskArray.push(task.due_date);
    taskArray.push(task.due_time);
    taskArray.push(task.period_id);
    //INSERT INTO `organiser`.`task` (`user_id`, `priority_id`, `group_id`, `title`, `description`, `start_date`, `start_time`, `due_date`, `due_time`, `period_id`) VALUES ('1', '1', '1', 'project creation', 'project for organiser', '26.08.2017', '10:00', '31.08.2017', '17:00', '2');
    //var sql=  "INSERT INTO `result` SET id_result = (SELECT id FROM user WHERE name = 'Tanya' limit 1), result ="1", date = NOW()"
   
/*    var sql = "INSERT INTO task"+ 
              "SET user_id = ?,"+
              //"SET user_id = (select user.id from user where username = ?),"+
              "SET priority_id = ?,"+
              "SET group_id =  ?,"+
              "SET title =  ?,"+
              "SET description = ?,"+
              "SET start_date = ?,"+
              "SET start_time = ?,"+
              "SET due_date = ?,"+
              "SET due_time = ?,"+
              "SET period_id = ?";
*/

   var sql = "INSERT INTO task (user_id, priority_id, group_id, title, description, start_date, start_time, due_date, due_time, period_id) VALUES ?";
    //var values = [taskArray];

    con.query(sql, [[taskArray]], function (err, result) {
        if (err) throw err;
        console.log("Number of records inserted into Task: " + result.affectedRows);
    });
};

exports.updateTask = function (task) {

    //INSERT INTO `user` (`name`) VALUES ('John'); 
    var user_id = task.user_id;
    var group_id = task.group_id;
    var priority_id = task.priority_id;
    var period_id = task.period_id;
    var title = task.title;
    var description = task.description;
    var start_date = task.start_date;
    var start_time = task.start_time;
    var due_date = task.due_date;
    var due_time = task.due_time;
    var sql = "UPDATE task "+
              "SET "+
              "priority_id = ?,"+
              "group_id = ?,"+
              "period_id = ?,"+
              "title = ?,"+
              "description = ? ,"+
              "start_date = ?,"+
              "start_time = ?, "+
              "due_date = ? ,"+
              "due_time = ? "+
              "WHERE user_id = ?;" ;
    con.query(sql, [priority_id, group_id, period_id, title, description, start_date, start_time, due_date, due_time, user_id], function (err, result) {
        if (err) throw err;
        console.log("Number of records updated: " + result.affectedRows);
    });
};

exports.deleteTask = function(id) {

    var sql= "DELETE FROM task WHERE id=?"
    con.query(sql, id, function(err, result) {
        if (err) throw err;
        console.log("Number of records deleted: " + result.affectedRows);    
    });
}

exports.getPeriodCollection = function(func) {
    
    var sqlPeriod = "SELECT * FROM period";
    var periodCollection = [];

    con.query(sqlPeriod, function (err, result) {
      if (err) throw err;
      for (var i = 0; i < result.length; i++) {
         periodCollection.push(result[i]);
      }
      func(JSON.stringify(periodCollection));
    });
};

exports.getPriorityCollection = function(func) {

    var sqlPriority = "SELECT * FROM priority";
    var priorityCollection =[];

    con.query(sqlPriority, function (err, result) {

        if (err) throw err;
        for (var i = 0; i < result.length; i++) {
            priorityCollection.push(result[i]);
        }

      func(JSON.stringify(priorityCollection));
    });
};

exports.getGroupCollection = function(func) {

    var sqlGroup = "SELECT * FROM `group`";
    var groupCollection =[];

    con.query(sqlGroup, function (err, result) {

        if (err) throw err;
        for (var i = 0; i < result.length; i++) {
            groupCollection.push(result[i]);
       }
       func(JSON.stringify(groupCollection));
    });
};

function selectAll(table) {

    var sql = "SELECT * FROM " + table;
    con.query(sql, function (err, result) {
        if (err) throw err;
        console.log("Number of records : ");
        for (var i = 0; i < result.length; i++)
            console.log(result[i].id + " " + result[i].name)
    });
};

/*SELECT 
    task.title,
    task.description,
    priority.priority,
    `group`.group,
    task.start_date,
    task.start_time,
    task.due_date,
    task.due_time,
    user.username
FROM
    task
JOIN priority 
ON   task.priority_id = priority.id
JOIN `group`
ON   task.group_id = `group`.id
JOIN user
ON    task.user_id = user.id;
*/
exports.getTaskCollectionById = function (id, func) {

    var results = [];
    //SELECT user.name, result.result, result.date FROM result, user WHERE user.id=result.id_result AND user.id=2;
    var sql = "SELECT task.title, task.description, priority.priority,`group`.group, period.period, task.start_date, task.start_time, task.due_date, task.due_time, user.username"+
              " FROM task, priority, `group`, period,  user "+
              " WHERE task.user_id = ? AND task.priority_id = priority.id AND task.group_id= `group`.id";
    con.query(sql,[[id]], function (err, result) {

        if (err) throw err;
        for (var i = 1; i < result.length; i++) {

            console.log(result[i].tile + " " + result[i].description + " " + result[i].priority);
            var obj = {
                title: result[i].title,
                description: result[i].description,
                priority: result[i].priority,
                period: result[i].period,
                group: result[i].group,
                start_date: result[i].start_date,
                start_time: result[i].start_time,
                due_date: result[i].due_date,
                due_time: result[i].due_time,
                username: result[i].username
            }
            results.push(obj);
        }
        console.log(results)
        func(JSON.stringify(results));
    });
};
exports.getTaskCollectionInPeriod = function(id, start_date,  due_date) {

    var sql = "SELECT task.title, task.description, priority.priority,`group`.group, period.period, task.start_date, task.start_time, task.due_date, task.due_time, user.username"+
              " FROM task, priority, `group`, period,  user "+
              " WHERE (task.user_id = ? AND task.priority_id = priority.id AND task.group_id= `group`.id AND"+
             " ((task.start_date >= "+start_date+" AND task.start_date <="+due_date+") OR (task.due_date >= "+start_date+" AND task.due_date <="+due_date+")"+
              " OR (task.start_date<="+start_date+ " AND due_date >= "+due_date+" )))";
              // OR (task.start_date>="+start_date+ " AND due_date <= "+due_date+")))";
              //" ((task.start_date<="+start_date+ " AND due_date >= "+due_date+" ) OR (task.start_date>="+start_date+ " AND due_date <= "+due_date+")))";
   
    con.query(sql,[[id]], function (err, result) {
        if (err) throw err;
        for (var i = 1; i < result.length; i++) {

            var obj = {
                title: result[i].title,
                description: result[i].description,
                priority: result[i].priority,
                period: result[i].period,
                group: result[i].group,
                start_date: result[i].start_date,
                start_time: result[i].start_time,
                due_date: result[i].due_date,
                due_time: result[i].due_time,
                username: result[i].username
            }
            results.push(obj);
                    console.log(result[i]);

        }
        //func(JSON.stringify(results));
    });
}
function testSelect() {

    // var sql = "SELECT id FROM user WHERE name = '"+record.name+"' limit 1";
    var sql = "SELECT * FROM task";

    con.query(sql, function (err, result) {
        if (err) throw err;
        console.log("Number of records : ");
        for (var i = 0; i < result.length; i++)
            console.log(result[i])
    });


};





var record = {
    name: 'Ivo',
    result: 1
};

//working insert select group
/*
exports.insertGroup('juniors');
exports.getGroupCollection();
*/
//working insert, get, delete priority
/*
exports.insertPriority('urgent');
exports.getPriorityCollection();
*/

//insert period, get, delete period
/*exports.deletePeriod(2);
exports.insertPeriod('year');
exports.getPeriodCollection();
*/
// insert task
var date = new Date();
var start_date = date.getDate()+1;
console.log(start_date);

var task = {
    user_id : 2,
    priority_id :1,
    group_id : 2,
    period_id :3,
    title: 'Write homework',
    description: 'Create program for calendar',
    start_date : '2017-07-06',
    start_time : '12:00:00',
    due_date   : '2017-08-25', 
    due_time   : '19:00:00'
}
//workin insert, get tasks
//exports.insertTask(task);
//exports.joinTables(1, null);

//working insertUser, updateToken, getUserCollection
//exports.insertUser('Cvety','Cvety@abv.bg','ypass');
//exports.updateToken('Gery', 'Gery@abv.bg', 'dhahd778j8a');
//exports.getUserCollection(null);

//working inserttASK, updateTask, deleteTask
//! update not the current date but the previous
//exports.updateTask(task);
//exports.insertTask(task)
//exports.joinTables(1, null);
//exports.deleteTask(4)

//exports.getTaskCollectionInPeriod(2,'2017-08-02', '2017-08-20');
//console.log('----')
//testSelect();