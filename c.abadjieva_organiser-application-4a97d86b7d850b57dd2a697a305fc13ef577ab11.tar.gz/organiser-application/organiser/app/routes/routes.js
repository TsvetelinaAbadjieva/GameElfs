
const express = require('express');
const app = express();

var http = require('http').Server(app);
var mysql = require('mysql');
var fc = require('../db/dbQueries');
var path = require('path');

var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Access-Control-Allow-Headers, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE'); next();
});

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root"

});

app.get('/', function (req, res) {
  var data = {
    "Data": ''
  };
  data['Data'] = 'welcome';
  res.json(data);
});

//module.exports = function(app) {


app.get('/task/:id', function (req, res) {

  //res.send(fc.joinTables(1));
  fc.getTaskCollectionById(req.params.id, function (data) {
    res.send(data);
  });
});

//get data from table `group` to fill a select list in task.js
app.get('/group', function (req, res) {

  fc.getGroupCollection(function (data) {
    res.send(data);
  });
});

//get data from table `priority` to fill a select list in task.js
app.get('/priority', function (req, res) {

  //res.send(fc.joinTables(1));
  fc.getPriorityCollection(function (data) {
    res.send(data);
    console.log(data);
  });
});

//get data from table `period` to fill a select list in task.js
app.get('/period', function (req, res) {

  //res.send(fc.joinTables(1));
  fc.getPeriodCollection(function (data) {
    res.send(data);
  });
});

app.post('/user', function (req, res) {

  //res.send(fc.joinTables(1));
  fc.insertResult(req.body, function (err, res) {
    if (err) {
      throw err;
    }
    res.send('Record inserted');
  });
});

app.post('/insertuser', function (req, res) {

  //res.send(fc.joinTables(1));
  fc.insertUser(req.body, function (err, res) {
    if (err) {
      throw err;
    }
    res.send({ status: 200, message: 'Record inserted' });
  });
});

app.post('/task', function (req, res) {

  //res.send(fc.joinTables(1));
  fc.insertTask(req.body, function (err, res) {
    if (err) {
      throw err;
    }
    res.send({ status: 200, message: 'Record inserted' });
  });
});


module.exports = app;
app.listen(8000, function () {
  console.log('Organiser app listening on port 8000!')
});